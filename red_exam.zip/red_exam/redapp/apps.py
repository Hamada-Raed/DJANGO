from django.apps import AppConfig


class RedappConfig(AppConfig):
    name = 'redapp'
